#!/bin/bash
# Test script to simulate the interactive checker with all test cases

set -e

echo "=========================================="
echo "TESTING MULTI-TEST INTERACTIVE PROBLEM"
echo "=========================================="
echo ""

# Compile everything
echo "Compiling interactor..."
g++ -std=c++17 -O2 -o interactor interactor.cpp
echo "Compiling solution..."
g++ -std=c++17 -O2 -o solution_fixed solution_fixed.cpp
echo "✅ Compiled successfully"
echo ""

# Test Case 1
echo "=========================================="
echo "TEST CASE 1: T=3, secrets [42, 50, 30]"
echo "=========================================="
echo "Test 1.1: max=100, secret=42"
echo "Test 1.2: max=50, secret=50"
echo "Test 1.3: max=30, secret=30"
echo ""

# Run solution with all test cases
printf "3\n100\n50\n30\n" | ./solution_fixed 2>&1 || true

echo ""
echo "---"
echo "Expected output:"
echo "Test 1.1 should output ! 42"
echo "Test 1.2 should output ! 50"  
echo "Test 1.3 should output ! 30"
echo "=========================================="
echo ""

# Test Case 2
echo "=========================================="
echo "TEST CASE 2: T=2, secrets [1, 100]"
echo "=========================================="
cat 2.txt
cat 2_answer.txt
printf "2\n100\n500\n" | ./solution_fixed 2>&1 || true
echo "=========================================="
echo ""

# Test Case 3
echo "=========================================="
echo "TEST CASE 3: T=2, secrets [283, 777]"
echo "=========================================="
cat 3.txt
cat 3_answer.txt
printf "2\n500\n1000\n" | ./solution_fixed 2>&1 || true
echo "=========================================="
echo ""

echo "✅ All tests completed!"

