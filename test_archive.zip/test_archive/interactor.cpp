#include <iostream>
#include <string>
using namespace std;

int main() {
    // Line 1: public input (could be T for multi-test, or max range for single test)
    string line1;
    getline(cin, line1);
    
    // Line 2: secret answer
    int secret;
    cin >> secret;
    
    // Line 3: user's query or answer
    string symbol;
    int value;
    cin >> symbol >> value;
    
    if (symbol == "?") {
        if (secret < value) {
            cout << "<" << endl;
        } else if (secret > value) {
            cout << ">" << endl;
        } else {
            cout << "=" << endl;
        }
    } else if (symbol == "!") {
        if (value == secret) {
            cout << "AC" << endl;
            return 0;
        } else {
            cout << "WA\n";
            cout << line1 << "\n"; 
            cout << "Value: " << value << " Secret: " << secret << endl;
            return 1;
        }
    }
    
    return 0;
}

