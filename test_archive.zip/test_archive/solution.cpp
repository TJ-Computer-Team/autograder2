#include <iostream>
#include <string>
using namespace std;

int main() {
    int t;
    cin >> t;
    
    while (t--) {
        int l = 1, r;
        cin >> r;
        
        while (l <= r) {
            int m = l + (r - l) / 2;
            cout << "? " << m << endl;
            string s;
            cin >> s;
            
            if (s == "=") {
                cout << "! " << m << endl;
                return 0;
            } else if (s == "<") {
                r = m - 1;
            } else { // s == ">"
                l = m + 1;
            }
        }
        // Fallback
        cout << "! " << l << endl;
    }
}
