#!/usr/bin/env python3
"""
Simulate the interactive checker to test the solution with all test cases.
This properly pipes between solution and interactor.
"""

import subprocess
import sys

def run_test_case(test_num):
    """Run a single test case file"""
    print(f"\n{'='*70}")
    print(f"RUNNING TEST CASE {test_num}")
    print(f"{'='*70}")
    
    # Read test files
    with open(f"{test_num}.txt", 'r') as f:
        test_input = f.read()
    with open(f"{test_num}_answer.txt", 'r') as f:
        answer_input = f.read()
    with open(f"{test_num}_queries.txt", 'r') as f:
        max_queries = int(f.read().strip())
    
    print(f"Test input: {repr(test_input)}")
    print(f"Answer input: {repr(answer_input)}")
    print(f"Max queries: {max_queries}")
    print(f"{'='*70}\n")
    
    # Parse inputs
    test_lines = test_input.strip().split('\n')
    answer_lines = answer_input.strip().split('\n')
    
    T = int(test_lines[0])
    print(f"Number of test cases: {T}")
    
    # Start solution process
    sol_proc = subprocess.Popen(
        ["./solution_fixed"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1
    )
    
    # Send T first
    try:
        sol_proc.stdin.write(test_lines[0] + "\n")
        sol_proc.stdin.flush()
    except Exception as e:
        print(f"ERROR sending T: {e}")
        return False
    
    query_count = 0
    test_num_internal = 0
    
    try:
        while test_num_internal < T:
            print(f"\n--- Sub-test {test_num_internal + 1} of {T} ---")
            
            # Get test case data
            max_range = int(test_lines[test_num_internal + 1])
            secret = int(answer_lines[test_num_internal + 1])
            print(f"Max range: {max_range}, Secret: {secret}")
            
            # Send max range to solution
            sol_proc.stdin.write(str(max_range) + "\n")
            sol_proc.stdin.flush()
            
            # Read queries and respond
            while query_count < max_queries * T:
                line = sol_proc.stdout.readline()
                if not line:
                    print(f"Solution terminated without completing test {test_num_internal + 1}")
                    return False
                
                line = line.strip()
                print(f"Solution → {line}")
                
                if line.startswith("?"):
                    query_count += 1
                    guess = int(line.split()[1])
                    
                    # Call interactor
                    interactor_input = f"{max_range}\n{secret}\n{line}\n"
                    result = subprocess.run(
                        ["./interactor"],
                        input=interactor_input,
                        capture_output=True,
                        text=True,
                        timeout=1.0
                    )
                    
                    response = result.stdout.strip()
                    print(f"Interactor → {response}")
                    
                    # Send to solution
                    sol_proc.stdin.write(response + "\n")
                    sol_proc.stdin.flush()
                
                elif line.startswith("!"):
                    answer = int(line.split()[1])
                    print(f"Solution submitted answer: {answer}")
                    
                    # Check answer
                    interactor_input = f"{max_range}\n{secret}\n{line}\n"
                    result = subprocess.run(
                        ["./interactor"],
                        input=interactor_input,
                        capture_output=True,
                        text=True,
                        timeout=1.0
                    )
                    
                    verdict = result.stdout.strip()
                    print(f"Interactor → {verdict}")
                    
                    if "AC" in verdict:
                        print(f"✅ Test {test_num_internal + 1} PASSED")
                        test_num_internal += 1
                        break
                    else:
                        print(f"❌ Test {test_num_internal + 1} FAILED")
                        return False
                
                if query_count >= max_queries:
                    print(f"❌ Query limit exceeded")
                    return False
            
            if test_num_internal >= T:
                print(f"\n✅ ALL TESTS PASSED")
                return True
        
        return True
        
    except Exception as e:
        print(f"ERROR: {e}")
        return False
    finally:
        sol_proc.terminate()
        try:
            sol_proc.wait(timeout=1)
        except:
            sol_proc.kill()

def main():
    print("="*70)
    print("INTERACTIVE CHECKER SIMULATION TEST")
    print("="*70)
    
    # Compile
    print("\nCompiling...")
    subprocess.run(["g++", "-std=c++17", "-O2", "-o", "interactor", "interactor.cpp"], check=True)
    subprocess.run(["g++", "-std=c++17", "-O2", "-o", "solution_fixed", "solution_fixed.cpp"], check=True)
    print("✅ Compiled")
    
    # Run tests
    passed = 0
    failed = 0
    
    for test_num in [1, 2, 3]:
        if run_test_case(test_num):
            passed += 1
        else:
            failed += 1
    
    print(f"\n{'='*70}")
    print(f"RESULTS: {passed} passed, {failed} failed")
    print(f"{'='*70}")
    
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    sys.exit(main())

